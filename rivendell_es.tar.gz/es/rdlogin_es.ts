<!DOCTYPE TS><TS>
<context>
    <name>MainWidget</name>
    <message>
        <source>RDLogin - Station:</source>
        <translation>RDLogin - Estación:</translation>
    </message>
    <message>
        <source>Can&apos;t Connect</source>
        <translation>No puedo conectarme</translation>
    </message>
    <message>
        <source>Current User:</source>
        <translation>Usuario actual:</translation>
    </message>
    <message>
        <source>RDLogin</source>
        <translation>RDLogin</translation>
    </message>
    <message>
        <source>&amp;Set User</source>
        <translation>&amp;Asignar Usuario</translation>
    </message>
    <message>
        <source>&amp;Default
User</source>
        <translation>Usuario por
&amp;Omisión</translation>
    </message>
    <message>
        <source>Invalid Password!</source>
        <translation>¡Contraseña inválida!</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancelar</translation>
    </message>
    <message>
        <source>Current User: unknown</source>
        <translation>Usuario actual: desconocido</translation>
    </message>
    <message>
        <source>&amp;Username:</source>
        <translation>&amp;Usuario:</translation>
    </message>
    <message>
        <source>&amp;Password:</source>
        <translation>&amp;Contraseña:</translation>
    </message>
    <message>
        <source>rdlogin : </source>
        <translation>rdlogin : </translation>
    </message>
</context>
</TS>
