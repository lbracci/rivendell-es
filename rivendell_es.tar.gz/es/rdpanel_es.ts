<!DOCTYPE TS><TS>
<context>
    <name>MainWidget</name>
    <message>
        <source>rdpanel : </source>
        <translation>rdpanel : </translation>
    </message>
    <message>
        <source>Can&apos;t Connect</source>
        <translation>No puedo conectarme</translation>
    </message>
</context>
</TS>
