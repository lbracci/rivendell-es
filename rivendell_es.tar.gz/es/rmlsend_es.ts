<!DOCTYPE TS><TS>
<context>
    <name>MainWidget</name>
    <message>
        <source>RMLSend - Macro Command Utility</source>
        <translation>RMLSend - Utilidad para comandos macro</translation>
    </message>
    <message>
        <source>RML</source>
        <translation>RML</translation>
    </message>
    <message>
        <source>RML (no echo)</source>
        <translation>RML (sin eco)</translation>
    </message>
    <message>
        <source>Set Port</source>
        <translation>Asig. puerto</translation>
    </message>
    <message>
        <source>UDP Port:</source>
        <translation>Puerto UDP:</translation>
    </message>
    <message>
        <source>Command:</source>
        <translation>Comando:</translation>
    </message>
    <message>
        <source>Response:</source>
        <translation>Respuesta:</translation>
    </message>
    <message>
        <source>&amp;Send Command</source>
        <translation>&amp;Enviar Comando</translation>
    </message>
    <message>
        <source>RMLSend</source>
        <translation>RMLSend</translation>
    </message>
    <message>
        <source>Invalid Port Number!</source>
        <translation>¡Número de puerto inválido!</translation>
    </message>
    <message>
        <source>Connection Failed!</source>
        <translation>¡Conexión fallida!</translation>
    </message>
    <message>
        <source>no response</source>
        <translation>sin respuesta</translation>
    </message>
</context>
</TS>
