<!DOCTYPE TS><TS>
<context>
    <name></name>
    <message>
        <source>UNKNOWN CUT</source>
        <translation>AUDIO DESCONOCIDO</translation>
    </message>
</context>
<context>
    <name>@default</name>
    <message>
        <source>ALL</source>
        <translation>TODO</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Couldn&apos;t initialize QSql driver!</source>
        <translation>¡No pude inicializar el driver QSql!</translation>
    </message>
    <message>
        <source>Couldn&apos;t open mySQL connection!</source>
        <translation>¡No pude abrir la conexión mySQL!</translation>
    </message>
</context>
<context>
    <name>RDAddCart</name>
    <message>
        <source>&amp;Group:</source>
        <translation>&amp;Grupo:</translation>
    </message>
    <message>
        <source>&amp;New Cart Number:</source>
        <translation>&amp;Nro. de cartucho:</translation>
    </message>
    <message>
        <source>&amp;New Cart Type:</source>
        <translation>&amp;Tipo de cartucho:</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Audio</translation>
    </message>
    <message>
        <source>Macro</source>
        <translation>Macro</translation>
    </message>
    <message>
        <source>[new cart]</source>
        <translation>[nuevo cartucho]</translation>
    </message>
    <message>
        <source>&amp;New Cart Title:</source>
        <translation>&amp;Título del cartucho:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Aceptar</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancelar</translation>
    </message>
    <message>
        <source>No Available Cart Numbers</source>
        <translation>No hay números disponibles</translation>
    </message>
    <message>
        <source>There are no more available cart numbers for the group!</source>
        <translation>¡No hay más números de cartuchos disponibles en este grupo!</translation>
    </message>
    <message>
        <source>Invalid Number</source>
        <translation>Número inválido</translation>
    </message>
    <message>
        <source>Invalid Cart Number!</source>
        <translation>¡El número de cartucho es inválido!</translation>
    </message>
    <message>
        <source>Title Required</source>
        <translation>Título requerido</translation>
    </message>
    <message>
        <source>You must enter a cart title!</source>
        <translation>¡Debe suministrar un título para el cartucho!</translation>
    </message>
    <message>
        <source>The cart number is outside of the permitted range for this group!</source>
        <translation>¡Ha colocado un número del cartucho fuera del rango permitido para este grupo!</translation>
    </message>
    <message>
        <source>Cart Exists</source>
        <translation>El cartucho ya existe</translation>
    </message>
    <message>
        <source>This cart already exists.</source>
        <translation>Este cartucho ya existe.</translation>
    </message>
    <message>
        <source>Duplicate Title</source>
        <translation>Título duplicado</translation>
    </message>
    <message>
        <source>The cart title must be unique!</source>
        <translation>¡El título del cartucho debe ser único!</translation>
    </message>
</context>
<context>
    <name>RDAddLog</name>
    <message>
        <source>Create Log</source>
        <translation>Crear playlist</translation>
    </message>
    <message>
        <source>&amp;New Log Name:</source>
        <translation>&amp;Nuevo nombre:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Aceptar</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancelar</translation>
    </message>
    <message>
        <source>RDLogEdit</source>
        <translation>RDLogEdit</translation>
    </message>
    <message>
        <source>The name is invalid!</source>
        <translation>¡El nombre es inválido!</translation>
    </message>
    <message>
        <source>&amp;Service:</source>
        <translation>&amp;Servicio:</translation>
    </message>
    <message>
        <source>The service is invalid!</source>
        <translation>¡El servicio es inválido!</translation>
    </message>
</context>
<context>
    <name>RDAudioSettingsDialog</name>
    <message>
        <source>Edit Settings</source>
        <translation>Editar parámetros</translation>
    </message>
    <message>
        <source>Default &amp;Format:</source>
        <translation>Formato por &amp;Omisión:</translation>
    </message>
    <message>
        <source>Default &amp;Channels:</source>
        <translation>&amp;Canales por omisión:</translation>
    </message>
    <message>
        <source>Default &amp;Sample Rate:</source>
        <translation>&amp;Sampleo por omisión:</translation>
    </message>
    <message>
        <source>Default &amp;Bitrate:</source>
        <translation>&amp;Tasa de bits por omisión:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Aceptar</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancelar</translation>
    </message>
    <message>
        <source>PCM16</source>
        <translation>PCM16</translation>
    </message>
    <message>
        <source>OggVorbis</source>
        <translation>OggVorbis</translation>
    </message>
    <message>
        <source>MPEG Layer 2</source>
        <translation>MPEG Capa 2</translation>
    </message>
    <message>
        <source>MPEG Layer 3</source>
        <translation>MPEG Capa 3</translation>
    </message>
</context>
<context>
    <name>RDButtonDialog</name>
    <message>
        <source>Edit Button</source>
        <translation>Editar botón</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation>Etiq.:</translation>
    </message>
    <message>
        <source>Cart:</source>
        <translation>Cart.:</translation>
    </message>
    <message>
        <source>Set
Cart</source>
        <translation>Asignar
Cartucho</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>Limpiar</translation>
    </message>
    <message>
        <source>Set
Color</source>
        <translation>Asignar
Color</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Aceptar</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancelar</translation>
    </message>
    <message>
        <source>NOT FOUND</source>
        <translation>NO ENCONTRADO</translation>
    </message>
</context>
<context>
    <name>RDCardSelector</name>
    <message>
        <source>Card:</source>
        <translation>Tarjeta:</translation>
    </message>
    <message>
        <source>Port:</source>
        <translation>Puerto:</translation>
    </message>
</context>
<context>
    <name>RDCart</name>
    <message>
        <source>Sequentially</source>
        <translation>Secuencialmente</translation>
    </message>
    <message>
        <source>Randomly</source>
        <translation>Aleatoriamente</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Desconocida</translation>
    </message>
    <message>
        <source>Feature</source>
        <translation>Característica</translation>
    </message>
    <message>
        <source>Theme Open</source>
        <translation>Entrada del tema</translation>
    </message>
    <message>
        <source>Theme Close</source>
        <translation>Salida del tema</translation>
    </message>
    <message>
        <source>Theme Open/Close</source>
        <translation>Entrada/Salida</translation>
    </message>
    <message>
        <source>Background</source>
        <translation>Fondo</translation>
    </message>
    <message>
        <source>Commercial/Jingle/Promo</source>
        <translation>Comercial/Jingle/promo</translation>
    </message>
</context>
<context>
    <name>RDCartDialog</name>
    <message>
        <source>Select Cart</source>
        <translation>Elegir Cartucho</translation>
    </message>
    <message>
        <source>Cart Filter:</source>
        <translation>Filtrar:</translation>
    </message>
    <message>
        <source>C&amp;lear</source>
        <translation>&amp;Limpiar</translation>
    </message>
    <message>
        <source>Group:</source>
        <translation>Grupo:</translation>
    </message>
    <message>
        <source>NUMBER</source>
        <translation>NÚMERO</translation>
    </message>
    <message>
        <source>LENGTH</source>
        <translation>DURACIÓN</translation>
    </message>
    <message>
        <source>TITLE</source>
        <translation>TÍTULO</translation>
    </message>
    <message>
        <source>ARTIST</source>
        <translation>ARTISTA<byte value="x9"/></translation>
    </message>
    <message>
        <source>CLIENT</source>
        <translation>CLIENTE</translation>
    </message>
    <message>
        <source>AGENCY</source>
        <translation>AGENCIA</translation>
    </message>
    <message>
        <source>USER DEF</source>
        <translation>OTROS</translation>
    </message>
    <message>
        <source>START</source>
        <translation>INICIO</translation>
    </message>
    <message>
        <source>END</source>
        <translation>FIN</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Aceptar</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancelar</translation>
    </message>
    <message>
        <source>ALL</source>
        <translation>ALL</translation>
    </message>
    <message>
        <source>GROUP</source>
        <translation>GRUPO</translation>
    </message>
    <message>
        <source>Send to
&amp;Editor</source>
        <translation>Enviar al
&amp;Editor</translation>
    </message>
    <message>
        <source>&amp;Search</source>
        <translation>&amp;Buscar</translation>
    </message>
    <message>
        <source>Please Wait...</source>
        <translation>Por favor, espere...</translation>
    </message>
    <message>
        <source>Show Only First</source>
        <translation>Mostrar los primeros</translation>
    </message>
    <message>
        <source>Matches</source>
        <translation>resultados</translation>
    </message>
    <message>
        <source>Scheduler Code:</source>
        <translation>Cód. Musicaliz.:</translation>
    </message>
</context>
<context>
    <name>RDCutDialog</name>
    <message>
        <source>Select Cut</source>
        <translation>Seleccione audio</translation>
    </message>
    <message>
        <source>Cart Filter:</source>
        <translation>Filtro:</translation>
    </message>
    <message>
        <source>C&amp;lear</source>
        <translation>&amp;Limpiar</translation>
    </message>
    <message>
        <source>Group:</source>
        <translation>Grupo:</translation>
    </message>
    <message>
        <source>Carts</source>
        <translation>Cartuchos</translation>
    </message>
    <message>
        <source>NUMBER</source>
        <translation>NÚMERO</translation>
    </message>
    <message>
        <source>TITLE</source>
        <translation>TÍTULO</translation>
    </message>
    <message>
        <source>Cuts</source>
        <translation>Audios</translation>
    </message>
    <message>
        <source>DESCRIPTION</source>
        <translation>DESCRIPCIÓN</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Aceptar</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancelar</translation>
    </message>
    <message>
        <source>ALL</source>
        <translation></translation>
    </message>
    <message>
        <source>&amp;Clear</source>
        <translation>&amp;Limpiar</translation>
    </message>
    <message>
        <source>&amp;Add New
Cart</source>
        <translation>&amp;Añadir
Cartucho</translation>
    </message>
    <message>
        <source>GROUP</source>
        <translation>GRUPO</translation>
    </message>
    <message>
        <source>Please Wait...</source>
        <translation>Espere...</translation>
    </message>
    <message>
        <source>&amp;Search</source>
        <translation>&amp;Buscar</translation>
    </message>
    <message>
        <source>Show Only First</source>
        <translation>Mostrar los primeros</translation>
    </message>
    <message>
        <source>Matches</source>
        <translation>resultados</translation>
    </message>
    <message>
        <source>Scheduler Code:</source>
        <translation>Cód. Musicaliz.:</translation>
    </message>
</context>
<context>
    <name>RDDateDialog</name>
    <message>
        <source>Select Date</source>
        <translation>Seleccione la fecha</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>Acepta&amp;r</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancelar</translation>
    </message>
</context>
<context>
    <name>RDDatePicker</name>
    <message>
        <source>Mo</source>
        <translation>Lu</translation>
    </message>
    <message>
        <source>Tu</source>
        <translation>Ma</translation>
    </message>
    <message>
        <source>We</source>
        <translation>Mi</translation>
    </message>
    <message>
        <source>Th</source>
        <translation>Ju</translation>
    </message>
    <message>
        <source>Fr</source>
        <translation>Vi</translation>
    </message>
    <message>
        <source>Sa</source>
        <translation>Sá</translation>
    </message>
    <message>
        <source>Su</source>
        <translation>Do</translation>
    </message>
</context>
<context>
    <name>RDEditAudio</name>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Guardar</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancelar</translation>
    </message>
    <message>
        <source>Amplitude</source>
        <translation>Amplitud</translation>
    </message>
    <message>
        <source>Zoom
In</source>
        <translation>Acercar
Zoom</translation>
    </message>
    <message>
        <source>Zoom
Out</source>
        <translation>Alejar
Zoom</translation>
    </message>
    <message>
        <source>Time</source>
        <translation>Tiemp</translation>
    </message>
    <message>
        <source>Full
In</source>
        <translation>Acercar
Máximo</translation>
    </message>
    <message>
        <source>Full
Out</source>
        <translation>Ver
Todo</translation>
    </message>
    <message>
        <source>Goto</source>
        <translation>Ir a</translation>
    </message>
    <message>
        <source>Cursor</source>
        <translation>Cursor</translation>
    </message>
    <message>
        <source>Home</source>
        <translation>Principio</translation>
    </message>
    <message>
        <source>End</source>
        <translation>Final</translation>
    </message>
    <message>
        <source>Cut
Start</source>
        <translation>Inicio del
audio</translation>
    </message>
    <message>
        <source>Cut
End</source>
        <translation>Fin del
audio</translation>
    </message>
    <message>
        <source>Talk
Start</source>
        <translation>Inicio
Hablar</translation>
    </message>
    <message>
        <source>Segue
Start</source>
        <translation>Inicio
Segue</translation>
    </message>
    <message>
        <source>Segue
End</source>
        <translation>Fin
Segue</translation>
    </message>
    <message>
        <source>Fade
Up</source>
        <translation>Fade
entrada</translation>
    </message>
    <message>
        <source>Hook
Start</source>
        <translation>Inicio
Hook</translation>
    </message>
    <message>
        <source>Hook
End</source>
        <translation>Fin 
Hook</translation>
    </message>
    <message>
        <source> dB</source>
        <translation> dB</translation>
    </message>
    <message>
        <source>Threshold</source>
        <translation>Nivel</translation>
    </message>
    <message>
        <source>Trim
Start</source>
        <translation>Inicio
Recorte</translation>
    </message>
    <message>
        <source>Trim
End</source>
        <translation>Fin del
recorte</translation>
    </message>
    <message>
        <source>Cut Gain</source>
        <translation>Ganancia
del audio</translation>
    </message>
    <message>
        <source>Remove
Marker</source>
        <translation>Eliminar
marcador</translation>
    </message>
    <message>
        <source>Position</source>
        <translation>Posición</translation>
    </message>
    <message>
        <source>Length</source>
        <translation>Longitud</translation>
    </message>
    <message>
        <source>Delete Talk Markers</source>
        <translation>Eliminar marcadores de hablar</translation>
    </message>
    <message>
        <source>Delete Segue Markers</source>
        <translation>Eliminar marcadores Segue</translation>
    </message>
    <message>
        <source>Delete Hook Markers</source>
        <translation>Eliminar marcadores Hook</translation>
    </message>
    <message>
        <source>Delete Fade Up Marker</source>
        <translation>Eliminar marcador Fade entrada</translation>
    </message>
    <message>
        <source>Delete Fade Down Marker</source>
        <translation>Eliminar marcador Fade salida</translation>
    </message>
    <message>
        <source>dB</source>
        <translation>dB</translation>
    </message>
    <message>
        <source>&lt;none&gt;</source>
        <translation>&lt;ninguno&gt;</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation>Cortar</translation>
    </message>
    <message>
        <source>Talk</source>
        <translation>Hablar</translation>
    </message>
    <message>
        <source>Segue</source>
        <translation>Segue</translation>
    </message>
    <message>
        <source>Hook</source>
        <translation>Hook</translation>
    </message>
    <message>
        <source>Fade Up</source>
        <translation>Fade de entrada</translation>
    </message>
    <message>
        <source>Fade Down</source>
        <translation>Fade de salida</translation>
    </message>
    <message>
        <source>L</source>
        <translation>Iz</translation>
    </message>
    <message>
        <source>R</source>
        <translation>De</translation>
    </message>
    <message>
        <source>No Fade on Segue Out</source>
        <translation>Quitar fade en Segue</translation>
    </message>
    <message>
        <source>Rivendell Web Service</source>
        <translation>Servicio web Rivendell</translation>
    </message>
    <message>
        <source>Unable to download peak data, error was:
&quot;</source>
        <translation>No fue posible descargar datos de picos, el error fue:
&quot;</translation>
    </message>
    <message>
        <source>Edit Audio</source>
        <translation>Editar Audio</translation>
    </message>
</context>
<context>
    <name>RDEditPanelName</name>
    <message>
        <source>Edit Panel Name</source>
        <translation>Editar nombre del panel</translation>
    </message>
    <message>
        <source>Panel &amp;Name:</source>
        <translation>&amp;Nombre del panel:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Aceptar</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancelar</translation>
    </message>
</context>
<context>
    <name>RDExceptionDialog</name>
    <message>
        <source>Rivendell Exception Report</source>
        <translation>Reporte de excepciones</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Guardar</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Cerrar</translation>
    </message>
    <message>
        <source>Text (*.txt *.TXT)
All Files (*.*)</source>
        <translation>Texto (*.txt *.TXT)
Todos los archivos (*.*)</translation>
    </message>
    <message>
        <source>Export File</source>
        <translation>Exportar archivo</translation>
    </message>
    <message>
        <source>The file</source>
        <translation>El archivo </translation>
    </message>
    <message>
        <source>already exists!
Overwrite?</source>
        <translation>ya existe.
¿Sobreescribir?</translation>
    </message>
    <message>
        <source>File Exists</source>
        <translation>El archivo ya existe</translation>
    </message>
    <message>
        <source>Unable to open file</source>
        <translation>¡No es posible abrir el archivo</translation>
    </message>
    <message>
        <source>for writing!</source>
        <translation>para escritura!</translation>
    </message>
    <message>
        <source>File Error</source>
        <translation>Error de archivo</translation>
    </message>
</context>
<context>
    <name>RDExportSettingsDialog</name>
    <message>
        <source>Edit Export Settings</source>
        <translation>Editar parám. exportación</translation>
    </message>
    <message>
        <source>&amp;Channels:</source>
        <translation>&amp;Canales:</translation>
    </message>
    <message>
        <source>&amp;Sample Rate:</source>
        <translation>Tasa de &amp;Muestreo:</translation>
    </message>
    <message>
        <source>&amp;Bitrate:</source>
        <translation>&amp;Tasa de bits:</translation>
    </message>
    <message>
        <source>&amp;Quality:</source>
        <translation>&amp;Calidad:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Aceptar</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancelar</translation>
    </message>
    <message>
        <source>PCM16</source>
        <translation>PCM16</translation>
    </message>
    <message>
        <source>FLAC</source>
        <translation>FLAC</translation>
    </message>
    <message>
        <source>MPEG Layer 2</source>
        <translation>MPEG Capa 2</translation>
    </message>
    <message>
        <source>MPEG Layer 3</source>
        <translation>MPEG Capa 3</translation>
    </message>
    <message>
        <source>OggVorbis</source>
        <translation>OggVorbis</translation>
    </message>
    <message>
        <source>VBR</source>
        <translation>VBR</translation>
    </message>
    <message>
        <source>32 kbps</source>
        <translation></translation>
    </message>
    <message>
        <source>64 kbps</source>
        <translation></translation>
    </message>
    <message>
        <source>96 kbps</source>
        <translation></translation>
    </message>
    <message>
        <source>128 kbps</source>
        <translation></translation>
    </message>
    <message>
        <source>160 kbps</source>
        <translation></translation>
    </message>
    <message>
        <source>192 kbps</source>
        <translation></translation>
    </message>
    <message>
        <source>224 kbps</source>
        <translation></translation>
    </message>
    <message>
        <source>256 kbps</source>
        <translation></translation>
    </message>
    <message>
        <source>288 kbps</source>
        <translation></translation>
    </message>
    <message>
        <source>320 kbps</source>
        <translation></translation>
    </message>
    <message>
        <source>352 kbps</source>
        <translation></translation>
    </message>
    <message>
        <source>384 kbps</source>
        <translation></translation>
    </message>
    <message>
        <source>416 kbps</source>
        <translation></translation>
    </message>
    <message>
        <source>448 kbps</source>
        <translation></translation>
    </message>
    <message>
        <source>48 kbps</source>
        <translation></translation>
    </message>
    <message>
        <source>56 kbps</source>
        <translation></translation>
    </message>
    <message>
        <source>80 kbps</source>
        <translation></translation>
    </message>
    <message>
        <source>112 kbps</source>
        <translation></translation>
    </message>
    <message>
        <source>40 kbps</source>
        <translation></translation>
    </message>
    <message>
        <source>8 kbps</source>
        <translation></translation>
    </message>
    <message>
        <source>16 kbps</source>
        <translation></translation>
    </message>
    <message>
        <source>24 kbps</source>
        <translation></translation>
    </message>
    <message>
        <source>144 kbps</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>RDGetAth</name>
    <message>
        <source>ATH:</source>
        <translation>ATH:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Aceptar</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancelar</translation>
    </message>
    <message>
        <source>Enter ATH</source>
        <translation>Introduzca ATH</translation>
    </message>
    <message>
        <source>Enter the agreggate tuning hours (ATH)
figure for the report period.
(Supplied by your streaming provider).</source>
        <translation>Introduzca las horas de sintonización (ATH)
para el período a reportar.
(Suministrado por su proveedor de streaming).</translation>
    </message>
    <message>
        <source>Invalid ATH</source>
        <translation>ATH inválido</translation>
    </message>
    <message>
        <source>You must provide a valid ATH figure!</source>
        <translation>¡Usted debe proveer una figura ATH válida!</translation>
    </message>
</context>
<context>
    <name>RDGetPasswd</name>
    <message>
        <source>Enter password</source>
        <translation>Introduzca clave</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Aceptar</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancelar</translation>
    </message>
    <message>
        <source>Enter Password</source>
        <translation>Introduzca la clave</translation>
    </message>
</context>
<context>
    <name>RDGpioSelector</name>
    <message>
        <source>Pin:</source>
        <translation>Pin:</translation>
    </message>
</context>
<context>
    <name>RDImportAudio</name>
    <message>
        <source>Import/Export Audio File</source>
        <translation>Importar/Exportar audio</translation>
    </message>
    <message>
        <source>Import File</source>
        <translation>Importar Archivo</translation>
    </message>
    <message>
        <source>Filename:</source>
        <translation>Archivo:</translation>
    </message>
    <message>
        <source>&amp;Select</source>
        <translation>&amp;Seleccionar</translation>
    </message>
    <message>
        <source>Import file metadata</source>
        <translation>Importar metadatos</translation>
    </message>
    <message>
        <source>Channels:</source>
        <translation>Canales:</translation>
    </message>
    <message>
        <source>Autotrim</source>
        <translation>Autorecortar</translation>
    </message>
    <message>
        <source>Level:</source>
        <translation>Nivel:</translation>
    </message>
    <message>
        <source>dBFS</source>
        <translation>dBFS</translation>
    </message>
    <message>
        <source>Export File</source>
        <translation>Exportar archivo</translation>
    </message>
    <message>
        <source>Export file metadata</source>
        <translation>Exportar metadatos</translation>
    </message>
    <message>
        <source>Format:</source>
        <translation>Formato:</translation>
    </message>
    <message>
        <source>S&amp;et</source>
        <translation>&amp;Asignar</translation>
    </message>
    <message>
        <source>Normalize</source>
        <translation>Normalizar</translation>
    </message>
    <message>
        <source>&amp;Import</source>
        <translation>&amp;Importar</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancelar</translation>
    </message>
    <message>
        <source>Export</source>
        <translation>Exportar</translation>
    </message>
    <message>
        <source>Import</source>
        <translation>Importar</translation>
    </message>
    <message>
        <source>Unable to open the file for writing!</source>
        <translation type="obsolete">¡No es posible escribir en el archivo!</translation>
    </message>
    <message>
        <source>Import Complete</source>
        <translation>Importación finalizada</translation>
    </message>
    <message>
        <source>Import complete!</source>
        <translation>¡Importación finalizada!</translation>
    </message>
    <message>
        <source>Import Aborted</source>
        <translation type="obsolete">Importación cancelada</translation>
    </message>
    <message>
        <source>The import has been aborted.</source>
        <translation type="obsolete">La importación ha sido abortada.</translation>
    </message>
    <message>
        <source>Import Failed</source>
        <translation type="obsolete">Falló la importación</translation>
    </message>
    <message>
        <source>The importer encountered an error.
Please check your importer configuration and try again.</source>
        <translation type="obsolete">El importador de audio encontró un error.
Revise la configuración e intente de nuevo.</translation>
    </message>
    <message>
        <source>File Exists</source>
        <translation>El archivo ya existe</translation>
    </message>
    <message>
        <source>The selected file already exists!
Do you want to overwrite it?</source>
        <translation>¡El archivo seleccionado ya existe!
¿Desea sobreescribirlo?</translation>
    </message>
    <message>
        <source>File Error</source>
        <translation type="obsolete">Error de archivo</translation>
    </message>
    <message>
        <source>Cannot open file in archive!</source>
        <translation type="obsolete">¡No puedo abrir el archivo!</translation>
    </message>
    <message>
        <source>Unsupported file type in archive!</source>
        <translation type="obsolete">¡Tipo de audio no soportado!</translation>
    </message>
    <message>
        <source>Export Complete</source>
        <translation>Exportación finalizada</translation>
    </message>
    <message>
        <source>Export complete!</source>
        <translation>¡Exportación finalizada!</translation>
    </message>
    <message>
        <source>Export Aborted</source>
        <translation type="obsolete">Exportación cancelada</translation>
    </message>
    <message>
        <source>The export has been aborted.</source>
        <translation type="obsolete">Se ha abortado la exportación.</translation>
    </message>
    <message>
        <source>Export Failed</source>
        <translation type="obsolete">Fallo en la exportación</translation>
    </message>
    <message>
        <source>The Exporter encountered an error.
Please check your configuration and try again.</source>
        <translation type="obsolete">El exportador de audio encontró un error.
Revise la configuración e inténtelo de nuevo.</translation>
    </message>
    <message>
        <source>No Access</source>
        <translation type="obsolete">Sin acceso</translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="obsolete">Aceptar</translation>
    </message>
    <message>
        <source>Import Audio File</source>
        <translation>Importar archivo de audio</translation>
    </message>
    <message>
        <source>File does not exist!</source>
        <translation>¡El archivo no existe!</translation>
    </message>
    <message>
        <source>Cannot open file!</source>
        <translation type="obsolete">No puedo abrir el archivo!</translation>
    </message>
    <message>
        <source>Unsupported file type!</source>
        <translation type="obsolete">¡Tipo de audio no soportado!</translation>
    </message>
    <message>
        <source>Audio Exists</source>
        <translation type="obsolete">El audio existe</translation>
    </message>
    <message>
        <source>This will overwrite the existing recording.
Do you want to proceed?</source>
        <translation type="obsolete">Esta acción sobreescribirá la grabación existente.
¿Desea continuar?</translation>
    </message>
    <message>
        <source>Empty Clipboard</source>
        <translation type="obsolete">Vaciar portapapeles</translation>
    </message>
    <message>
        <source>Importing this cut will also empty the clipboard.
Do you still want to proceed?</source>
        <translation type="obsolete">Importar este audio vaciará el portapapeles.
¿Desea continuar?</translation>
    </message>
    <message>
        <source>Export Error</source>
        <translation>Error exportando</translation>
    </message>
    <message>
        <source>Import Error</source>
        <translation>Error importando</translation>
    </message>
    <message>
        <source>Abort</source>
        <translation>Abortar</translation>
    </message>
</context>
<context>
    <name>RDIntegerDialog</name>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Aceptar</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancelar</translation>
    </message>
    <message>
        <source>Set Value</source>
        <translation>Asignar valor</translation>
    </message>
</context>
<context>
    <name>RDIntegerEdit</name>
    <message>
        <source>Add</source>
        <translation>Añadir</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <source>Set Value</source>
        <translation>Colocar valor</translation>
    </message>
</context>
<context>
    <name>RDLicense</name>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Cerrar</translation>
    </message>
    <message>
        <source>GNU Public License v2</source>
        <translation>Licencia Pública GNU v2</translation>
    </message>
</context>
<context>
    <name>RDListGroups</name>
    <message>
        <source>Select Group</source>
        <translation>Seleccionar grupo</translation>
    </message>
    <message>
        <source>NAME</source>
        <translation>NOMBRE</translation>
    </message>
    <message>
        <source>DESCRIPTION</source>
        <translation>DESCRIPCIÓN</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Aceptar</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancelar</translation>
    </message>
</context>
<context>
    <name>RDListLogs</name>
    <message>
        <source>Select Log - User: </source>
        <translation>Seleccionar Playlist - Usuario: </translation>
    </message>
    <message>
        <source>Select Log</source>
        <translation>Seleccionar Playlist</translation>
    </message>
    <message>
        <source>NAME</source>
        <translation>NOMBRE</translation>
    </message>
    <message>
        <source>DESCRIPTION</source>
        <translation>DESCRIPCIÓN</translation>
    </message>
    <message>
        <source>SERVICE</source>
        <translation>SERVICIO</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>ACEPTAR</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>RDListSelector</name>
    <message>
        <source>Available Services</source>
        <translation>Servicios disponibles</translation>
    </message>
    <message>
        <source>Add &gt;&gt;</source>
        <translation>Añadir &gt;&gt;</translation>
    </message>
    <message>
        <source>&lt;&lt; Remove</source>
        <translation>&lt;&lt; Remover</translation>
    </message>
    <message>
        <source>Active Services</source>
        <translation>Servicios Activos</translation>
    </message>
</context>
<context>
    <name>RDLogLine</name>
    <message>
        <source>Unknown</source>
        <translation>Desconocido</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation>Manual</translation>
    </message>
    <message>
        <source>Play</source>
        <translation>Reproducir</translation>
    </message>
    <message>
        <source>Segue</source>
        <translation>Segue</translation>
    </message>
    <message>
        <source>Time</source>
        <translation>Tiempo</translation>
    </message>
    <message>
        <source>Panel</source>
        <translation>Panel</translation>
    </message>
    <message>
        <source>Macro</source>
        <translation>Macro</translation>
    </message>
    <message>
        <source>PLAY</source>
        <translation>REPROD</translation>
    </message>
    <message>
        <source>SEGUE</source>
        <translation>SEGUE</translation>
    </message>
    <message>
        <source>STOP</source>
        <translation>DETENER</translation>
    </message>
    <message>
        <source>UNKNOWN</source>
        <translation>DESCONOCIDO</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Audio</translation>
    </message>
    <message>
        <source>Marker</source>
        <translation>Marcador</translation>
    </message>
    <message>
        <source>Open Bracket</source>
        <translation>Abrir llave</translation>
    </message>
    <message>
        <source>Close Bracket</source>
        <translation>Cerrar llave</translation>
    </message>
    <message>
        <source>ChainTo</source>
        <translation>ChainTo</translation>
    </message>
    <message>
        <source>Track</source>
        <translation>Pista</translation>
    </message>
    <message>
        <source>Link</source>
        <translation>Enlace</translation>
    </message>
    <message>
        <source>Traffic</source>
        <translation>Tráfico</translation>
    </message>
    <message>
        <source>Music</source>
        <translation>Música</translation>
    </message>
    <message>
        <source>RDLogManager</source>
        <translation>RDLogManager</translation>
    </message>
    <message>
        <source>Tracker</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>RDPasswd</name>
    <message>
        <source>Change Password</source>
        <translation>Cambiar contraseña</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Aceptar</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancelar</translation>
    </message>
    <message>
        <source>&amp;Password:</source>
        <translation>&amp;Contraseña:</translation>
    </message>
    <message>
        <source>C&amp;onfirm:</source>
        <translation>C&amp;onfirmar:</translation>
    </message>
    <message>
        <source>Password Mismatch</source>
        <translation>Las claves no concuerdan</translation>
    </message>
    <message>
        <source>The passwords don&apos;t match,
please try again!</source>
        <translation>Las contraseñas difieren entre sí,
¡inténtelo de nuevo!</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>Aceptar</translation>
    </message>
</context>
<context>
    <name>RDRecording</name>
    <message>
        <source>Recording</source>
        <translation>Grabación</translation>
    </message>
    <message>
        <source>Macro Event</source>
        <translation>Evento Macro</translation>
    </message>
    <message>
        <source>Switch Event</source>
        <translation>Suichear evento</translation>
    </message>
    <message>
        <source>Playout</source>
        <translation>Reproducción</translation>
    </message>
    <message>
        <source>Download</source>
        <translation>Descargar</translation>
    </message>
    <message>
        <source>Upload</source>
        <translation>Subir</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation>Aceptar</translation>
    </message>
    <message>
        <source>Short Length</source>
        <translation>Mostrar longitud</translation>
    </message>
    <message>
        <source>Low Level</source>
        <translation>Bajo nivel</translation>
    </message>
    <message>
        <source>High Level</source>
        <translation>Alto nivel</translation>
    </message>
    <message>
        <source>Downloading</source>
        <translation>Descargando</translation>
    </message>
    <message>
        <source>Uploading</source>
        <translation>Subiendo</translation>
    </message>
    <message>
        <source>Server Error</source>
        <translation>Error de servidor</translation>
    </message>
    <message>
        <source>Internal Error</source>
        <translation>Error interno</translation>
    </message>
    <message>
        <source>Interrupted</source>
        <translation>Interrumpido</translation>
    </message>
    <message>
        <source>Playing</source>
        <translation>Sonando</translation>
    </message>
    <message>
        <source>Waiting</source>
        <translation>Esperando</translation>
    </message>
    <message>
        <source>Device Busy</source>
        <translation>Disposit. ocupado</translation>
    </message>
    <message>
        <source>No Such Cart/Cut</source>
        <translation>El audio no existe</translation>
    </message>
    <message>
        <source>Unknown Audio Format</source>
        <translation>Formado desconocido</translation>
    </message>
</context>
<context>
    <name>RDReport</name>
    <message>
        <source>CBSI DeltaFlex Traffic Reconciliation v2.01</source>
        <translation>Reconciliación de tráfico CBSI DeltaFlex v2.01</translation>
    </message>
    <message>
        <source>Text Log</source>
        <translation>Texto plano</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Desconocido</translation>
    </message>
    <message>
        <source>Other</source>
        <translation>Otro</translation>
    </message>
    <message>
        <source>AM</source>
        <translation></translation>
    </message>
    <message>
        <source>FM</source>
        <translation></translation>
    </message>
    <message>
        <source>ASCAP/BMI Electronic Music Report</source>
        <translation>Reporte musical electrónico ASCAP/BMI</translation>
    </message>
    <message>
        <source>Technical Playout Report</source>
        <translation>Reporte técnico de reproducciones</translation>
    </message>
    <message>
        <source>SoundExchange Statutory License Report</source>
        <translation>Reporte de licencias SoundExchange</translation>
    </message>
    <message>
        <source>Report complete!</source>
        <translation>¡Reporte terminado!</translation>
    </message>
    <message>
        <source>Unable to open report file!</source>
        <translation>¡No es posible abrir el archivo de reporte!</translation>
    </message>
    <message>
        <source>Report canceled!</source>
        <translation>¡Reporte cancelado!</translation>
    </message>
    <message>
        <source>RadioTraffic.com Traffic Reconciliation</source>
        <translation>Reconciliación de tráfico RadioTraffic.com</translation>
    </message>
    <message>
        <source>VisualTraffic Reconciliation</source>
        <translation>Reconciliación VisualTraffic</translation>
    </message>
    <message>
        <source>CounterPoint Traffic Reconciliation</source>
        <translation>Reconciliación de tráfico CounterPoint</translation>
    </message>
    <message>
        <source>Music1 Reconciliation</source>
        <translation>Reconciliación Music1</translation>
    </message>
</context>
<context>
    <name>RDSoundPanel</name>
    <message>
        <source>Setup</source>
        <translation>Configurar</translation>
    </message>
    <message>
        <source>Cart</source>
        <translation>Cartucho</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Reiniciar</translation>
    </message>
    <message>
        <source>Panel</source>
        <translation>Panel</translation>
    </message>
    <message>
        <source>Play All</source>
        <translation>Completa</translation>
    </message>
    <message>
        <source>Play Hook</source>
        <translation>Sólo &quot;hook&quot;</translation>
    </message>
    <message>
        <source>All</source>
        <translation>Todo</translation>
    </message>
</context>
<context>
    <name>RDSqlDatabaseStatus</name>
    <message>
        <source>Database connection restored.</source>
        <translation>Se recuperó la conexión a la base de datos.</translation>
    </message>
    <message>
        <source>Database connection failed : </source>
        <translation>Falló la conexión a la base de datos : </translation>
    </message>
</context>
<context>
    <name>RDStereoMeter</name>
    <message>
        <source>L</source>
        <translation>Iz</translation>
    </message>
    <message>
        <source>R</source>
        <translation>De</translation>
    </message>
    <message>
        <source>CLIP</source>
        <translation>CLIP</translation>
    </message>
</context>
<context>
    <name>RDSvc</name>
    <message>
        <source>The following events were not placed:
</source>
        <translation>Los siguientes eventos no fueron colocados:
</translation>
    </message>
    <message>
        <source>[unknown cart]</source>
        <translation>[cartucho desconocido]</translation>
    </message>
    <message>
        <source>Event Fill Errors
</source>
        <translation>Errores al llenar eventos
</translation>
    </message>
</context>
</TS>
