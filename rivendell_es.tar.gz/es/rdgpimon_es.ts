<!DOCTYPE TS><TS>
<context>
    <name>MainWidget</name>
    <message>
        <source>Database Error</source>
        <translation>Error de base de datos</translation>
    </message>
    <message>
        <source>Can&apos;t Connect</source>
        <comment>Unable to connect to mySQL Server!</comment>
        <translation>No puedo conectarme</translation>
    </message>
    <message>
        <source>Can&apos;t Connect</source>
        <translation>No puedo conectarme</translation>
    </message>
    <message>
        <source>Unable to connect to mySQL Server!</source>
        <translation>¡No puedo conectarme al servidor MySQL!</translation>
    </message>
    <message>
        <source>Matrix:</source>
        <translation>Matriz:</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Cerrar</translation>
    </message>
    <message>
        <source>RDGpiMon - User:</source>
        <translation>RDGpiMon - Usuario:</translation>
    </message>
    <message>
        <source>Show:</source>
        <translation>Mostrar:</translation>
    </message>
    <message>
        <source>GPI (Inputs)</source>
        <translation>GPI (Entradas)</translation>
    </message>
    <message>
        <source>GPO (Outputs)</source>
        <translation>GPO (Salidas)</translation>
    </message>
    <message>
        <source>Green = ON Cart</source>
        <translation>Verde = Cartucho ENCENDIDO</translation>
    </message>
    <message>
        <source>Red = OFF Cart</source>
        <translation>Rojo = Cartucho APAGADO</translation>
    </message>
</context>
</TS>
